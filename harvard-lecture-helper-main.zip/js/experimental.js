/*global $, jQuery, alert*/

function array_subdivide(string) {
    var content = $(element).code();
    localStorage[sessionKey] = JSON.stringify(content);
}

function array_recombine(string) {
    var content = JSON.parse(localStorage[sessionKey]);
}